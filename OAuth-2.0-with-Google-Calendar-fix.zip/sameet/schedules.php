<?php
function m1(){
    $summary = '01. Annual general meeting';
    $description = 'Student Association Meetings (SAM)';
    $start = '2021-11-21T14:00:00+05:30';
    $end = '2021-11-21T17:00:00+05:30';
    include 'calendar.php';
}

function m2(){
    $summary = '02. Welfare meeting';
    $description = 'Student Association Meetings (SAM)';
    $start = '2021-11-30T14:00:00+05:30';
    $end = '2021-11-30T16:00:00+05:30';
    include 'calendar.php';
}

function m3(){
    $summary = '03. Progress meeting';
    $description = 'Student Association Meetings (SAM)';
    $start = '2021-12-21T14:00:00+05:30';
    $end = '2021-12-21T16:00:00+05:30';
    include 'calendar.php';
}
?>